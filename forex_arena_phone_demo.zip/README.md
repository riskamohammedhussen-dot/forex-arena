# Forex Arena — Full Platform Starter

This is the next development step after the visual prototype: a deployable starter with a web frontend and an API backend.

## Included
- Responsive competition website (reuses the prototype UI)
- Express API for public leaderboard and demo admin routes
- In-memory demo data (resets when server restarts)
- Clear MT5 integration adapter placeholder
- Environment configuration example

## Run locally
Requires Node.js 20+.
1. Extract the ZIP.
2. In this folder run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Important limitations
This is a starter, not a production-ready public platform. It is not connected to MT5 yet. Demo results are fictional.
Before public launch: replace in-memory storage with PostgreSQL or another durable database; add secure admin/user authentication, rate limits, input validation, HTTPS, audit logs, and verified MT5/broker data integration. Never collect broker/MT5 trading passwords from users. Do not distribute prizes or collect fees without reviewing applicable laws.
