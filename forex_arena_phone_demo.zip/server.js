const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || "local-demo-only-change-me";
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const START_BALANCE = 10000;
let traders = [
  { id: 1, name: "PipHunter", balance: 11840, trades: 42, status: "Sample data" },
  { id: 2, name: "Mekdes FX", balance: 11420, trades: 37, status: "Sample data" },
  { id: 3, name: "Abdi Trader", balance: 10980, trades: 25, status: "Sample data" },
  { id: 4, name: "BlueCandle", balance: 10650, trades: 31, status: "Sample data" },
  { id: 5, name: "NatiFX", balance: 10320, trades: 19, status: "Sample data" },
  { id: 6, name: "ForexLion", balance: 9860, trades: 28, status: "Sample data" }
];
let nextId = 7;

function leaderboard() {
  return traders.map(t => ({
    id: t.id, name: t.name, balance: t.balance,
    profit: Number((t.balance - START_BALANCE).toFixed(2)),
    returnPct: Number((((t.balance - START_BALANCE) / START_BALANCE) * 100).toFixed(2)),
    trades: t.trades, status: t.status
  })).sort((a, b) => b.returnPct - a.returnPct).map((t, i) => ({ rank: i + 1, ...t }));
}
app.get("/api/health", (_req, res) => res.json({ ok: true, mode: "demo", mt5Connected: false }));
app.get("/api/leaderboard", (_req, res) => res.json({
  competition: { name: "October Demo Sprint", startBalance: START_BALANCE, prizePool: 0, mode: "demo" },
  updatedAt: new Date().toISOString(),
  traders: leaderboard()
}));
app.post("/api/admin/traders", (req, res) => {
  if (req.get("x-admin-key") !== ADMIN_KEY) return res.status(401).json({ error: "Admin key required." });
  const { name, balance, trades } = req.body || {};
  if (typeof name !== "string" || !name.trim() || name.trim().length > 30 ||
      typeof balance !== "number" || !Number.isFinite(balance) || balance < 0 ||
      !Number.isInteger(trades) || trades < 0) {
    return res.status(400).json({ error: "Provide name, non-negative numeric balance, and non-negative integer trades." });
  }
  traders.push({ id: nextId++, name: name.trim(), balance, trades, status: "Unverified demo" });
  res.status(201).json({ trader: traders[traders.length - 1], leaderboard: leaderboard() });
});

// Integration seam only. A real MT5 connector must be implemented using a trusted
// broker/server-side data source; do not ask users for their trading passwords.
app.get("/api/integrations/mt5/status", (_req, res) => res.json({
  connected: false,
  message: "MT5 adapter not configured. No live trading data is being read."
}));

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Forex Arena running on http://localhost:${PORT}`));
